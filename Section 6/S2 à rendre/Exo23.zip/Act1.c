#include <stdio.h>
#include <stdlib.h>

int menu(){
    int nb;
	printf("1 - Cogner \n 2 - Se soigner \n 3 - Augmenter l'attaque \n 4 - Augmenter la défense \n");
    printf("Entrez votre choix\n >>>");
    if(scanf(" %d",&nb) != 1){
        while(getchar() != '\n'){}
        return menu();
    }
    while(getchar() != '\n') {}
    if (nb > 4 || nb < 1 ){ return menu(); }
    
    return nb;
}

int main(){
    
    
    printf("%d, Bien reçu",menu());
    return 1;
}