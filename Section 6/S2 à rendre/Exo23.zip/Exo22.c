/*

#include <stdio.h>
#include <stdlib.h>


    int main() {
        int first, second;
        char res;
        printf(">>> ");
        scanf("%d %c %d", &first, &res, &second);
    switch(res) {
        case '+' :
            int cal = first + second;
            printf(" = %d\n", cal);
            break;
            
        case '*' :
            long cal1 = (long)first * second;
            printf(" = %ld\n", cal1);
            break;
            
        case '/' :
        
            double cal2 = (double)first / second;
            printf(" = %lg\n", cal2);
            break;
}
return 1;
}

*/